from flask import Flask, request,url_for,redirect
from flask import render_template
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import Selectfield 

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home/home.html')

@app.route('/cours', methods=['GET', 'POST'])
def cours():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('home/cours.html')

@app.route('/eleves', methods=['GET', 'POST'])
def eleves():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('home/eleves.html')

@app.route('/reussis', methods=['GET', 'POST'])
def reussis():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('home/reussis.html')

@app.route('/infos', methods=['GET', 'POST'])
def infos():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('home/infos.html')
