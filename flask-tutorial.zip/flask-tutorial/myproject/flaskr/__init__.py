from flask import Flask, request,url_for,redirect
from flask import render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home/home.html')

@app.route('/cours', methods=['GET', 'POST'])
def cours():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('cours/cours.html')

@app.route('/eleves', methods=['GET', 'POST'])
def eleves():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('home/eleves.html')

@app.route('/reussis', methods=['GET', 'POST'])
def reussis():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('home/reussis.html')

@app.route('/infos', methods=['GET', 'POST'])
def infos():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('home/infos.html')

@app.route('/LSINF1101', methods=['GET', 'POST'])
def LSINF1101():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('cours/LSINF1101.html')

@app.route('/LEPL1402', methods=['GET', 'POST'])
def LEPL1402():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('cours/LEPL1402.html')

@app.route('/LSINF1252', methods=['GET', 'POST'])
def LSINF1252():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('cours/LSINF1252.html')

@app.route('/LINFO1103', methods=['GET', 'POST'])
def LINFO1103():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('cours/LINFO1103.html')
